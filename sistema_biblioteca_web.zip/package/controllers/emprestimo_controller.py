from flask import render_template, redirect, request
from package.models.emprestimo import Emprestimo, carregar_emprestimos, salvar_emprestimos
from package.models.usuario import carregar_usuarios
from package.models.livro import carregar_livros, salvar_livros

emprestimos = carregar_emprestimos()
usuarios = carregar_usuarios()
livros = carregar_livros()

def listar_emprestimos():
    return render_template("emprestimos.html", emprestimos=emprestimos, usuarios=usuarios, livros=livros)

def realizar_emprestimo(req):
    usuario_id = int(req.form["usuario_id"])
    livro_id = int(req.form["livro_id"])
    usuario = next((u for u in usuarios if u.id == usuario_id), None)
    livro = next((l for l in livros if l.id == livro_id and l.disponivel), None)

    if usuario and livro:
        emprestimo = Emprestimo(usuario, livro)
        emprestimos.append(emprestimo)
        livro.emprestar()
        salvar_emprestimos(emprestimos)
        salvar_livros(livros)
    return redirect("/emprestimos")

def devolver_livro(id):
    for emp in emprestimos:
        if emp.id == id and emp.data_devolucao is None:
            emp.devolver()
            salvar_emprestimos(emprestimos)
            salvar_livros(livros)
            break
    return redirect("/emprestimos")
