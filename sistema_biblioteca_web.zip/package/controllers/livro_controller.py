from flask import render_template, redirect, request
from package.models.livro import Livro, carregar_livros, salvar_livros

livros = carregar_livros()

def listar_livros():
    return render_template("livros.html", livros=livros)

def cadastrar_livro(req):
    titulo = req.form["titulo"]
    autor = req.form["autor"]
    ano = req.form["ano"]
    livro = Livro(titulo, autor, ano)
    livros.append(livro)
    salvar_livros(livros)
    return redirect("/livros")
