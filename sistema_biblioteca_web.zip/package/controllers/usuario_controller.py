from flask import render_template, redirect, request
from package.models.usuario import Usuario, carregar_usuarios, salvar_usuarios

usuarios = carregar_usuarios()

def listar_usuarios():
    return render_template("usuarios.html", usuarios=usuarios)

def cadastrar_usuario(req):
    nome = req.form["nome"]
    email = req.form["email"]
    usuario = Usuario(nome, email)
    usuarios.append(usuario)
    salvar_usuarios(usuarios)
    return redirect("/usuarios")
