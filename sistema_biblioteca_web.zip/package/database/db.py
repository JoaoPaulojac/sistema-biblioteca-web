import pickle
import os

def salvar_dados(nome_arquivo, dados):
    with open(f"package/database/{nome_arquivo}", "wb") as f:
        pickle.dump(dados, f)

def carregar_dados(nome_arquivo):
    caminho = f"package/database/{nome_arquivo}"
    if os.path.exists(caminho):
        with open(caminho, "rb") as f:
            return pickle.load(f)
    return []
