from package.database.db import salvar_dados, carregar_dados

class Usuario:
    contador = 1

    def __init__(self, nome, email):
        self.id = Usuario.contador
        self.nome = nome
        self.email = email
        Usuario.contador += 1

def salvar_usuarios(lista):
    salvar_dados("usuarios.pkl", lista)

def carregar_usuarios():
    return carregar_dados("usuarios.pkl")
