from datetime import datetime
from package.database.db import salvar_dados, carregar_dados

class Emprestimo:
    contador = 1

    def __init__(self, usuario, livro):
        self.id = Emprestimo.contador
        self.usuario = usuario
        self.livro = livro
        self.data_emprestimo = datetime.now()
        self.data_devolucao = None
        Emprestimo.contador += 1

    def devolver(self):
        self.data_devolucao = datetime.now()
        self.livro.devolver()

def salvar_emprestimos(lista):
    salvar_dados("emprestimos.pkl", lista)

def carregar_emprestimos():
    return carregar_dados("emprestimos.pkl")
