import pickle
from package.database.db import salvar_dados, carregar_dados

class ItemBiblioteca:
    def __init__(self, titulo, ano):
        self.titulo = titulo
        self.ano = ano

class Livro(ItemBiblioteca):
    contador = 1

    def __init__(self, titulo, autor, ano):
        super().__init__(titulo, ano)
        self.autor = autor
        self.id = Livro.contador
        self.disponivel = True
        Livro.contador += 1

    def emprestar(self):
        self.disponivel = False

    def devolver(self):
        self.disponivel = True

def salvar_livros(lista):
    salvar_dados("livros.pkl", lista)

def carregar_livros():
    return carregar_dados("livros.pkl")
